package tp1.pb.estoque.inventory.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity
@Table(name = "inventory_item", schema = "inventory")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @EqualsAndHashCode.Include
    private UUID id;

    @Column(name = "id_product", nullable = false, unique = true)
    private UUID productId;

    @Column(nullable = false)
    private Integer quantity;

    public InventoryItem(UUID productId) {
        if (productId == null){
            throw new IllegalArgumentException("Produto obrigatório");
        }
        this.productId = productId;
        this.quantity = 0;
    }
}