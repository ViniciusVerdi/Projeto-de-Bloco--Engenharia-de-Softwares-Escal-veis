package tp1.pb.estoque.catalog.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import tp1.pb.estoque.catalog.entities.Product;
import java.util.UUID;

public interface ProductRepository extends JpaRepository<Product, UUID> {}
