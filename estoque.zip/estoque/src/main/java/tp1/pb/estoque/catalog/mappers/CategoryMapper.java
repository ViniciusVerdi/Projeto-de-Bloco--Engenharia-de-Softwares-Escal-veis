package tp1.pb.estoque.catalog.mappers;

import org.mapstruct.Mapper;
import tp1.pb.estoque.catalog.dtos.responses.CategoryResponseDTO;
import tp1.pb.estoque.catalog.entities.Category;

@Mapper(componentModel = "spring")
public interface CategoryMapper {
    CategoryResponseDTO toResponse(Category category);
}
