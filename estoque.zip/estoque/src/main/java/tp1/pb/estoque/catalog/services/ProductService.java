package tp1.pb.estoque.catalog.services;

import org.springframework.stereotype.Service;
import tp1.pb.estoque.catalog.dtos.responses.ProductResponseDTO;
import tp1.pb.estoque.catalog.entities.Product;
import tp1.pb.estoque.catalog.mappers.ProductMapper;
import tp1.pb.estoque.catalog.repositories.ProductRepository;
import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;

    public ProductService(ProductRepository productRepository, ProductMapper productMapper) {
        this.productRepository = productRepository;
        this.productMapper = productMapper;
    }

    public List<ProductResponseDTO> getAll() {
        List<Product> products = productRepository.findAll();
        return productMapper.toDTO(products);
    }

}
