package tp1.pb.estoque.catalog.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tp1.pb.estoque.catalog.dtos.responses.ProductResponseDTO;
import tp1.pb.estoque.catalog.services.ProductService;

import java.util.List;

@RestController
@RequestMapping("/estoque")
public class ProductController {
    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }
    @GetMapping()
    public ResponseEntity<List<ProductResponseDTO>> getAllProducts() {
        List<ProductResponseDTO> productsDTO = this.productService.getAll();
        return ResponseEntity.status(HttpStatus.OK).body(productsDTO);
    }
}
